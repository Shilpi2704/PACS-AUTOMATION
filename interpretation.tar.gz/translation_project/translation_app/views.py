
from django.shortcuts import render
from django.urls import reverse
from django.contrib.auth import login, authenticate
from django.contrib import messages
from .forms import CustomAuthenticationForm

from django.contrib import messages
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.views import LoginView
from .forms import CustomAuthenticationForm  # Make sure to import your custom form
# translation_app/views.py
from translation_project import settings
from .forms import FileUploadForm
import os
import pandas as pd
from django.core.mail import send_mail
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
import random
from django.shortcuts import render, redirect
from django.http import FileResponse, HttpResponse
from django.conf import settings
from .models import UploadedFile
from openpyxl import Workbook
import concurrent.futures
from ai4bharat.transliteration import XlitEngine

from django.contrib import messages

def welcome(request):
    return render(request, 'welcome.html')



#-----------------------------------------------------

from django.shortcuts import render

def intro(request):
    return render(request, 'intro.html')



# Initialize the XlitEngine
e = XlitEngine(beam_width=10, src_script_type="indic")

target_language = 'en'
source_language = 'mr'

# Create a cache dictionary to store translations
translation_cache = {}

def translate_text(text):
    if isinstance(text, str) and text.strip():  
        if text in translation_cache:
            return translation_cache[text]
        else:
            translation = e.translit_sentence(text, 'mr')
            translation_cache[text] = translation  # Cache the translation
            return translation
    else:
        return text


def translate_file(request):
    if request.method == 'POST':
        file_id = request.POST.get('file_id')
        if file_id:
            uploaded_file = UploadedFile.objects.get(id=file_id)
            excel_file_path = uploaded_file.file.path
            xls = pd.ExcelFile(excel_file_path)
            sheet_names = xls.sheet_names

            for sheet_name in sheet_names:
                df = pd.read_excel(excel_file_path, sheet_name=sheet_name, header=None)
                columns = pd.read_excel(excel_file_path, sheet_name=sheet_name, header=None, nrows=1).iloc[0].tolist()
                columns_to_translate = list(range(len(columns)))

                with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
                    for column_name in columns_to_translate:
                        batch_size = 100
                        translated_data = []
                        batch = df[column_name].tolist()
                        for i in range(0, len(batch), batch_size):
                            translated_batch = list(executor.map(translate_text, batch[i:i + batch_size]))
                            translated_data.extend(translated_batch)
                        df[f'Translated_{column_name}'] = translated_data

                df.drop(columns=columns_to_translate, axis=1, inplace=True)
                output_file_path = os.path.join(settings.MEDIA_ROOT, 'translated_files', 'lib_excel.xlsx')
                
                df.to_excel(output_file_path, index=False)

            # Provide a download link for the translated file
            # Render a template with a success message
            # template = loader.get_template('success_template.html')
            # return HttpResponse(template.render())
            translated_file_path = output_file_path  # Replace with the actual path
            return render(request, 'confirmation_template.html', {'translated_file_path': translated_file_path})

    return redirect('upload')

def download_translated_file(request):
    if request.method == 'POST':
        file_path = request.POST.get('file_path')
        translated_file = open(file_path, 'rb')
        response = FileResponse(translated_file)
        response['Content-Disposition'] = 'attachment; filename="translated_file.xlsx"'
        return response
    return redirect('upload')

#--------------------------------------------------------
from django.shortcuts import render

def welcome(request):
    return render(request, 'welcome.html')

#-----------------------------------------------------------


def upload_file(request):
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_file = form.save()
            return redirect('confirmation', uploaded_file.id)
    else:
        form = FileUploadForm()
    return render(request, 'upload_file.html', {'form': form})



def confirmation(request, file_id):
    uploaded_file = UploadedFile.objects.get(id=file_id)
    return render(request, 'confirmation.html', {'uploaded_file': uploaded_file})


from django.contrib.auth import login, logout
from .forms import CustomAuthenticationForm


def logout_view(request):
    logout(request)
    return redirect('login')  # Redirect to your login page.



#-------------------------------------------------------------------


def register(request):
    error_message = ''

    if request.method == 'POST':
        form = UserCreationForm(request.POST)

        if form.is_valid():
            email = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            print(email)
            print(password)

            # Check if the email ends with the allowed domain
            if not email.endswith('@enfuse-solutions.com'):
                error_message = 'Only @enfuse-solutions.com email addresses are allowed.'
            else:
                # Generate OTP
                otp = str(random.randint(100000, 999999))
                print(otp)
                # Send OTP to the user's email
                send_mail('Verification Code', f'Your OTP: {otp}', email, [email])

                
                # Store the OTP in the session for verification
                request.session['verification_otp'] = otp
                request.session['email'] = email
                request.session['password'] = form.cleaned_data.get('password1')

                
                # Redirect to the OTP verification page
                return redirect('verify_otp')
        else:
            # Form data is not valid, set an error message
            error_message = 'User already exists with this email credentials.'

    else:
        form = UserCreationForm()

    return render(request, 'register.html', {'form': form, 'error_message': error_message})




#--------------------------------------------------------------------
from django.contrib.auth import login
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
import random
from django.core.mail import send_mail
from django.contrib.auth.models import User


def verify_otp(request):
    if request.method == 'POST':
        user_otp = request.POST.get('otp')
        stored_otp = request.session.get('verification_otp')
        
        if user_otp == stored_otp:
            # Email is verified; clear the OTP from the session
            del request.session['verification_otp']
            
            

            if 'email' in request.session and 'password' in request.session:
                email = request.session['email']
                password = request.session['password']

                print(email)
                print(password)

                
            # Create the user account
                user = User.objects.create_user(
                    username=email,  # Use email as the username
                    password=password  # Use the provided password
                )
                
                # Log in the user
                login(request, user)
                
                # Redirect to the registration complete page
                return redirect("login")
            else:
                return redirect("/login")
        else:
            # Invalid OTP, show an error message
            error_message = "Invalid OTP. Please enter the correct code."
            
            # Delete the email and password from the session
            if 'email' in request.session:
                del request.session['email']
            if 'password' in request.session:
                del request.session['password']

            context = {'error_message': error_message}

            return render(request, 'verify_otp.html', context)
    
    return render(request, 'verify_otp.html')


def login_view(request):
    error_message = ''
    if request.method == 'POST':
        form = CustomAuthenticationForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            user = authenticate(request, username=email, password=password)
            if user is not None:
                login(request, user)
                return redirect('upload')  # Redirect to the desired page after successful login
            else:
                error_message = 'Invalid email or password. Please try again.'
        else:
            error_message = 'Invalid form data. Please check your input.'
    else:
        form = CustomAuthenticationForm()

    return render(request, 'login.html', {'form': form, 'error_message': error_message})



from django.contrib.auth import authenticate, login
from django.contrib.auth.views import LoginView

class CustomLoginView(LoginView):
    template_name = 'login.html'  # Your login template

    def form_valid(self, form):
        user = form.get_user()
        login(self.request, user)
        print("Initiating LOOOOgin")
        return super().form_valid(form)


from django.shortcuts import render

def download_complete(request):
    return render(request, 'download_complete.html')