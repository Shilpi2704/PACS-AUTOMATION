# translation_app/urls.py
from django.urls import path
from translation_app import views
from translation_app.views import CustomLoginView
from django.views.generic import RedirectView


# translation_app/urls.py
from django.urls import path
from translation_app import views
from translation_app.views import CustomLoginView
from django.views.generic import RedirectView

urlpatterns = [
    path('upload/', views.upload_file, name='upload'),
    path('translate/', views.translate_file, name='translate'),
    path('confirmation/<int:file_id>/', views.confirmation, name='confirmation'),
    path('register/', views.register, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path("verify_otp/", views.verify_otp, name='verify_otp'),
    path('welcome/', views.welcome, name='welcome'),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('accounts/profile/', RedirectView.as_view(url='/upload', permanent=True), name='profile_redirect'),
    path('', views.intro, name='intro'),
    path('download_translated_file/', views.download_translated_file, name='download_translated_file'),
]
