# app_name/urls.py

from django.urls import path
from app import views

urlpatterns = [
    path('index_ocr/', views.index_ocr, name='index_ocr'),
    path('register_ocr/', views.register_ocr, name='register_ocr'),
    path('login_ocr/', views.login_ocr, name='login_ocr'),
    path('dashboard_ocr/', views.dashboard_ocr, name='dashboard_ocr'),
    path('upload_ocr/', views.upload_file_ocr, name='upload_ocr'),
    path('dashboard_ocr/upload_ocr/', views.upload_file_ocr, name='upload_ocr'),
    path('download_ocr/<str:filename>/', views.download_ocr, name='download_ocr'),
    path('logout_ocr/', views.logout_ocr, name='logout_ocr'),
    path('result_page/<path:filename>/', views.result_page, name='result_page'),
]
