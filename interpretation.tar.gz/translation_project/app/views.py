from django.shortcuts import render, redirect
from django.http import HttpResponse, FileResponse
import os
import time
import uuid
import zipfile
import re
import bcrypt
from app.models import OCRUser
from utility import create_zip_file, is_pdf_by_extension, delete_files, num_page_check, split_pdf, combine_excels
from google_utility import quickstart, process_pdf
from translation_project.settings import json_file_path
from django.contrib.auth.hashers import make_password
from django.contrib import messages
from django.http import FileResponse
from django.http import HttpResponse
from django.template import loader

# Constants and Path Definitions
excel_output_DIR = os.path.join(os.getcwd(), 'excel files')
pdf_output_DIR = os.path.join(os.getcwd(), 'split_pdfs')
output_DIR = os.path.join(os.getcwd(), 'output')
os.makedirs(excel_output_DIR, exist_ok=True)
os.makedirs(pdf_output_DIR, exist_ok=True)
os.makedirs(output_DIR, exist_ok=True)

# Service account credentials
translate_service_key = json_file_path
path_to_key = os.path.join(os.getcwd(), translate_service_key)

# Set the path to your service account key JSON file
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = path_to_key

project_id = "mindful-rhythm-402207"
location = "us"  # Format is "us" or "eu"

def index_ocr(request):
    return render(request, 'index_ocr.html')


def register_ocr(request):
    if request.method == 'POST':
        # Get user input
        username = request.POST.get('username')
        raw_password = request.POST.get('password')
        parser = request.POST.get('parser')

        # Additional condition for the username length
        if not (8 <= len(username) <= 25):
            error_message = 'Username must be between 8 and 25 characters long.'
            messages.error(request, error_message)
            return render(request, 'register_ocr.html')

        # Additional condition for the password length
        if not (8 <= len(raw_password) <= 16):
            error_message = 'Password must be between 8 and 16 characters long.'
            messages.error(request, error_message)
            return render(request, 'register_ocr.html')

        # Additional condition for the username format
        if not (parser.startswith('projects') and len(parser) == 62):
            error_message = 'Invalid Processor ID'
            messages.error(request, error_message)
            return render(request, 'register_ocr.html')

        # Check if the username already exists
        if OCRUser.objects.filter(username=username).exists():
            error_message = 'Username already exists. Please choose a different username.'
            messages.error(request, error_message)
            return render(request, 'register_ocr.html')

        # Hash the password
        password = make_password(raw_password)

        # Create and save the user
        new_user = OCRUser(username=username, password=password, parser=parser)
        new_user.save()

        return redirect('login_ocr')

    return render(request, 'register_ocr.html')



def login_ocr(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = OCRUser.objects.filter(username=username).first()
        
        if user and user.check_password(password):
            request.session['username'] = user.username
            return redirect('dashboard_ocr')
        else:
            return render(request, 'login_ocr.html', {'error': 'Invalid user'})

    return render(request, 'login_ocr.html')

def dashboard_ocr(request):
    if 'username' in request.session:
        user = OCRUser.objects.filter(username=request.session['username']).first()
        return render(request, 'dashboard_ocr.html', {'user': user})
    return redirect('login_ocr')




# ... (other imports)

def upload_file_ocr(request):
    if request.method == 'POST':
        if 'file' not in request.FILES:
            return redirect(request.path)
        
        file = request.FILES['file']
        if not file.name:
            return redirect(request.path)
        
        filename = file.name
        unique_filename = f"{str(uuid.uuid4())}_{filename}"
        
        with open(unique_filename, 'wb+') as destination:
            for chunk in file.chunks():
                destination.write(chunk)
        
        file_path = unique_filename
        unique_filename = re.sub(r'\.pdf|\.PDF', '', file_path.split('/')[-1])

        print("Checking user")
        
        if 'username' in request.session:
            user = OCRUser.objects.filter(username=request.session['username']).first()
            form_parser = user.parser
        
        # Continue with your file handling logic
        if is_pdf_by_extension(file_path):
            if num_page_check(file_path, 10):
                split_pdf(file_path, 10)
                pdf_files = os.listdir('split_pdfs')
                print("Stage 2")
                for pdf in pdf_files:
                    pdf_name = re.sub(r'\.pdf|\.PDF', '', pdf)
                    print("sub 1")
                    document = quickstart(project_id, location, os.path.join(pdf_output_DIR, pdf), form_parser)
                    print("sub 2")
                    process_pdf(document, pdf_name)
                    print("sub 3")
                excel_files = os.listdir(excel_output_DIR)
                print("sub 4")
                excel_files = [os.path.join(excel_output_DIR, file) for file in excel_files]
                print("sub 5")
                combine_excels(excel_files, unique_filename)
                print("sub 6")
                delete_files(pdf_output_DIR)
                delete_files(excel_output_DIR)
                print("sub 7")
                output_file = os.path.join(output_DIR, f'{unique_filename}_combined.xlsx')
            else:
                pdf_name = re.sub(r'\.pdf|\.PDF', '', file_path)
                document = quickstart(project_id, location, file_path, form_parser)
                process_pdf(document, pdf_name)
                output_file = os.path.join(excel_output_DIR, f'{unique_filename}.xlsx')

            translated_file_path = output_file  # Update this line with the correct path

        # Redirect to the result page with the translated file path
        return render(request, 'result_page.html', {'translated_file_path': translated_file_path})

    return render(request, 'upload_ocr.html')




def download_ocr(request, filename):
    file_path = os.path.join(output_DIR, filename)
    download_filename = 'OCR_file.xlsx'

    response = FileResponse(open(file_path, 'rb'), as_attachment=True)
    response['Content-Disposition'] = f'attachment; filename="{download_filename}"'
    return response

def logout_ocr(request):
    request.session.pop('username', None)
    return redirect('login_ocr')

def result_page(request, filename):
    return render(request, 'result_page.html', {'filename': filename})